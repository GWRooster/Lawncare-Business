-- =============================================
-- LOCAL LAWNCARE — Supabase Schema
-- Run this entire file in your Supabase SQL editor
-- =============================================

-- Services table
create table services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(6,2) not null,
  category text,
  sort_order int default 0,
  active boolean default true
);

insert into services (name, description, price, category, sort_order) values
  ('Front Yard Mow',     null,                           20.00, 'front', 1),
  ('Front Yard Edge',    null,                           5.00,  'front', 2),
  ('Back Yard Mow',      null,                           20.00, 'back',  3),
  ('Back Yard Edge',     null,                           5.00,  'back',  4),
  ('Full Yard Package',  'Includes light pre-mowing pick up', 40.00, 'package', 5);

-- Team members
create table team_members (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text unique not null,
  active boolean default true
);

-- Availability — each row is one open time slot
create table availability (
  id uuid primary key default gen_random_uuid(),
  team_member_id uuid references team_members(id) on delete cascade,
  date date not null,
  start_time time not null,
  end_time time not null,
  booked boolean default false,
  created_at timestamptz default now()
);

-- Bookings — created when a client selects a slot
create table bookings (
  id uuid primary key default gen_random_uuid(),
  availability_id uuid references availability(id) on delete set null,
  service_id uuid references services(id) on delete set null,
  client_name text not null,
  client_email text,
  client_phone text,
  client_address text not null,
  notes text,
  status text default 'confirmed',
  created_at timestamptz default now()
);

-- =============================================
-- Row Level Security
-- =============================================

alter table services enable row level security;
alter table team_members enable row level security;
alter table availability enable row level security;
alter table bookings enable row level security;

-- Public can read services and available slots
create policy "Public read services" on services for select using (active = true);
create policy "Public read availability" on availability for select using (booked = false);

-- Public can create bookings
create policy "Public create bookings" on bookings for insert with check (true);

-- Authenticated users (the boys) can do everything
create policy "Auth full access services" on services for all using (auth.role() = 'authenticated');
create policy "Auth full access availability" on availability for all using (auth.role() = 'authenticated');
create policy "Auth full access bookings" on bookings for all using (auth.role() = 'authenticated');
create policy "Auth full access team" on team_members for all using (auth.role() = 'authenticated');
